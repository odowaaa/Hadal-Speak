# Simple GitHub Setup - Alternative Method

Since you can't find the export button in Replit, here's a simple alternative approach:

## Method 1: Download and Upload (Easiest)

### Step 1: Download Your Project
1. **In Replit**, look for a **Download** button or **Export** option anywhere in the interface
2. **Or try**: Go to the file explorer, select all files, right-click → Download
3. **Save the zip file** to your computer

### Step 2: Create GitHub Repository
1. **Go to github.com** and sign in (create account if needed)
2. **Click the green "New" button** (top left)
3. **Repository name**: `hadal-english`
4. **Description**: `English learning app for Somali speakers`
5. **Make it Public** (required for GitHub Pages)
6. **Click "Create repository"**

### Step 3: Upload Files
1. **In your new GitHub repository**, click **"uploading an existing file"**
2. **Drag and drop** your downloaded files OR click "choose your files"
3. **Upload everything** from your project
4. **Commit message**: "Initial commit: Hadal English PWA"
5. **Click "Commit changes"**

## Method 2: Manual GitHub Connection

If download doesn't work, here's the command-line approach:

### Step 1: Get GitHub Repository URL
After creating your repository on GitHub, copy the URL:
`https://github.com/yourusername/hadal-english.git`

### Step 2: Connect in Replit Shell
Open the Shell/Terminal in Replit and run:

```bash
# Set up git user (one time only)
git config --global user.name "Your Name"
git config --global user.email "odowaa1996@gmail.com"

# Add GitHub as remote
git remote add origin https://github.com/yourusername/hadal-english.git

# Add all files
git add .

# Commit
git commit -m "Initial commit: Hadal English PWA ready for Google Play Store"

# Push to GitHub (you'll need to enter GitHub username and password)
git push -u origin main
```

## Step 3: Enable GitHub Pages (Both Methods)

1. **In your GitHub repository**, click **"Settings"** tab
2. **Scroll down to "Pages"** in the left sidebar
3. **Source**: Deploy from a branch
4. **Branch**: main
5. **Folder**: / (root)
6. **Click "Save"**

## Your Privacy Policy URL

After GitHub Pages is enabled (takes 5-10 minutes), your privacy policy will be available at:

```
https://yourusername.github.io/hadal-english/PRIVACY_POLICY.html
```

**Replace "yourusername" with your actual GitHub username.**

## For Google Play Console

Use this exact URL format in Google Play Console:
```
https://yourusername.github.io/hadal-english/PRIVACY_POLICY.html
```

## Test Your Setup

After 10-15 minutes, visit these URLs to confirm:
- `https://yourusername.github.io/hadal-english/` (should show README)
- `https://yourusername.github.io/hadal-english/PRIVACY_POLICY.html` (your privacy policy)

## Need Help?

If you get stuck:
1. **Try Method 1 first** (download/upload) - it's the simplest
2. **GitHub has help documentation** at help.github.com
3. **Contact me** with any specific error messages

Your privacy policy and all deployment files are ready - you just need to get them on GitHub for the required HTTPS URL!