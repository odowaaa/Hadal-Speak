# GitHub Setup Guide for Hadal English

## Step 1: Create GitHub Repository

1. **Go to GitHub.com** and sign in (or create account)
2. **Click "New Repository"** (green button)
3. **Repository Settings**:
   - **Name**: `hadal-english`
   - **Description**: `English learning app for Somali speakers - mobile-first PWA with bilingual content`
   - **Public** (required for GitHub Pages)
   - ✅ **Add README file** (uncheck this - we already have one)
   - ✅ **Add .gitignore** (uncheck this - we already have one)
   - **License**: MIT

## Step 2: Connect Replit to GitHub

### Option A: Export to GitHub (Recommended)
1. **In Replit**: Click the three dots (⋯) next to your repl name
2. **Select "Export to GitHub"**
3. **Sign in to GitHub** when prompted
4. **Choose your GitHub username** and repository name
5. **Click "Export"**

### Option B: Manual Setup
If export doesn't work, manually connect:

```bash
# Add GitHub as remote origin
git remote add origin https://github.com/yourusername/hadal-english.git

# Add all files
git add .

# Commit changes
git commit -m "Initial commit: Hadal English PWA with Google Play Store ready setup"

# Push to GitHub
git push -u origin main
```

## Step 3: Set Up GitHub Pages for Privacy Policy

1. **Go to your repository** on GitHub.com
2. **Click "Settings"** tab
3. **Scroll to "Pages"** in left sidebar
4. **Source**: Deploy from a branch
5. **Branch**: main / root
6. **Click "Save"**

Your privacy policy will be available at:
`https://yourusername.github.io/hadal-english/PRIVACY_POLICY.html`

## Step 4: Update Privacy Policy Links

### In Google Play Console:
Use this URL for your privacy policy:
```
https://yourusername.github.io/hadal-english/PRIVACY_POLICY.html
```

### Test Your Privacy Policy URL:
After GitHub Pages deploys (5-10 minutes), visit:
- `https://yourusername.github.io/hadal-english/`
- `https://yourusername.github.io/hadal-english/PRIVACY_POLICY.html`

## Step 5: Repository Structure

Your GitHub repository will contain:
```
hadal-english/
├── README.md                           # Project overview
├── PRIVACY_POLICY.md                   # For Google Play Store
├── GOOGLE_PLAY_DEPLOYMENT_GUIDE.md     # Deployment instructions
├── DEPLOYMENT_SUMMARY.md               # Quick summary
├── client/                             # React PWA frontend
├── server/                             # Node.js backend
├── shared/                             # Shared TypeScript schemas
├── package.json                        # Dependencies
└── .gitignore                          # Git ignore rules
```

## Step 6: Ongoing Development

### Making Changes:
1. **Edit in Replit** as usual
2. **Export changes** using "Export to GitHub" button
3. **Or commit manually**:
   ```bash
   git add .
   git commit -m "Update: description of changes"
   git push
   ```

### Automatic Updates:
- Every time you export to GitHub, your privacy policy updates automatically
- GitHub Pages rebuilds within 5-10 minutes
- Your privacy policy URL stays the same

## Benefits of GitHub Setup:

✅ **Privacy Policy Hosting**: Required HTTPS URL for Google Play Store
✅ **Version Control**: Track all changes to your app
✅ **Backup**: Your code is safely stored on GitHub
✅ **Collaboration**: Share with other developers if needed
✅ **Professional Portfolio**: Showcase your work
✅ **Free Hosting**: GitHub Pages is completely free

## Important URLs After Setup:

- **Repository**: `https://github.com/yourusername/hadal-english`
- **Privacy Policy**: `https://yourusername.github.io/hadal-english/PRIVACY_POLICY.html`
- **Live App**: Your Replit deployment URL
- **Documentation**: Available in your repository

## Troubleshooting:

### If GitHub Pages doesn't work:
1. Check repository is **public**
2. Ensure **Pages is enabled** in repository settings
3. Wait 10-15 minutes for deployment
4. Try accessing: `https://yourusername.github.io/hadal-english/`

### If privacy policy link doesn't work:
1. Ensure `PRIVACY_POLICY.md` is in repository root
2. GitHub Pages automatically converts `.md` to `.html`
3. Use `.html` extension in Google Play Console: `/PRIVACY_POLICY.html`

## Next Steps:

1. ✅ Create GitHub repository
2. ✅ Export/connect your Replit project
3. ✅ Enable GitHub Pages
4. ✅ Test privacy policy URL
5. ✅ Use URL in Google Play Console submission

Your app is ready for professional deployment! 🚀