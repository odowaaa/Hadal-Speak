# Hadal English - Language Learning App

## Overview

Hadal English is a mobile-first language learning application designed specifically to help Somali-speaking adults learn English through practical daily-life lessons. The app features three progressive learning levels, bilingual content with Somali translations, interactive quizzes, and voice practice capabilities. Built with modern web technologies, it provides an engaging and user-friendly learning experience.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Enhancements (January 2025)

### Google Play Store Deployment Preparation (January 30, 2025)
✓ **PWA Manifest**: Complete manifest.json with all required fields for Play Store
✓ **Service Worker**: Offline functionality and caching implementation
✓ **App Icons**: SVG icon design ready for PNG conversion (192x192 and 512x512)
✓ **Meta Tags**: SEO and PWA meta tags added to HTML
✓ **Deployment Guide**: Comprehensive step-by-step Google Play Store deployment guide
✓ **App Store Optimization**: Keywords, descriptions, and store listing preparation
✓ **Developer Info**: Contact details integrated for Play Store verification

## Recent Enhancements (January 2025)

### Professional Features Added
✓ **Study Streak System**: Weekly goal tracking with visual progress
✓ **Advanced Progress Tracking**: Detailed lesson completion indicators
✓ **Vocabulary Flashcards**: Interactive flip cards with examples
✓ **Pronunciation Guides**: Phonetic assistance with practice feedback
✓ **Cultural Context Tips**: Culturally sensitive learning guidance
✓ **Advanced Settings Panel**: Comprehensive audio, learning, and notification preferences
✓ **Enhanced Voice Recording**: Improved practice interface with feedback
✓ **Multi-modal Practice**: Speaking, vocabulary, and pronunciation modes
✓ **Completion Modals**: Encouraging feedback with progress celebration

### Content Quality Improvements
✓ **Verified Somali Translations**: All content reviewed for cultural appropriateness
✓ **Enhanced Lesson Structure**: Professional lesson planning with cultural context
✓ **Audio System Enhancement**: Multiple language support with voice options
✓ **Improved Spelling**: Comprehensive review of all bilingual content
✓ **Cultural Sensitivity**: Appropriate context and examples for Somali learners

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: Shadcn/UI with Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for lightweight client-side routing
- **Mobile-First Design**: Responsive layout optimized for mobile devices

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Style**: RESTful endpoints with JSON responses
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon Database)
- **Session Storage**: PostgreSQL-based session storage

### Data Storage Solutions
- **Primary Database**: PostgreSQL with Drizzle ORM
- **Schema Management**: Type-safe schema definitions in shared directory
- **Migration System**: Drizzle Kit for database migrations
- **Development Storage**: In-memory storage for development/demo purposes

## Key Components

### Core Data Models
1. **Users**: User accounts with language preferences and progress tracking
2. **Lessons**: Structured content with English/Somali pairs and key vocabulary
3. **User Progress**: Individual lesson completion and quiz scores
4. **Quiz Questions**: Multiple-choice questions for lesson assessment

### Learning Features
1. **Three-Level System**:
   - Level 1: Beginner (greetings, basic phrases, numbers)
   - Level 2: Intermediate (conversations, daily situations)
   - Level 3: Advanced (storytelling, formal communication)

2. **Interactive Components**:
   - Audio playback using Web Speech API
   - Voice recording for pronunciation practice
   - Multiple-choice quizzes with immediate feedback
   - Progress tracking and completion status

3. **Bilingual Support**:
   - English-Somali content pairs
   - Key vocabulary translations
   - Language toggle functionality
   - Cultural context integration

### UI Components
- **Responsive Cards**: Lesson and level selection interfaces
- **Audio Players**: Text-to-speech functionality for both languages
- **Voice Recorder**: Microphone access for pronunciation practice
- **Progress Indicators**: Visual feedback for learning advancement
- **Navigation**: Bottom navigation bar for mobile UX

## Data Flow

1. **User Journey**: Home → Level Selection → Lesson Content → Quiz → Progress Update
2. **Content Delivery**: Lessons fetched by level, progressive unlocking based on completion
3. **Progress Tracking**: Real-time updates to user completion status and scores
4. **Audio Processing**: Client-side speech synthesis and recording capabilities

## External Dependencies

### Core Technologies
- **React Ecosystem**: React Query for data fetching, React Router alternative (Wouter)
- **UI Libraries**: Radix UI primitives, Lucide React icons, Class Variance Authority
- **Database**: Neon PostgreSQL, Drizzle ORM with Zod validation
- **Development**: TypeScript, Vite, ESBuild for production builds

### Browser APIs
- **Web Speech API**: For text-to-speech functionality
- **MediaDevices API**: For microphone access and voice recording
- **Local Storage**: For client-side preferences and temporary data

## Deployment Strategy

### Development Environment
- **Hot Reload**: Vite development server with HMR
- **Replit Integration**: Cartographer plugin for Replit environment
- **Error Handling**: Runtime error overlay for development debugging

### Production Build
- **Frontend**: Vite build process generating optimized static assets
- **Backend**: ESBuild bundling for Node.js server deployment
- **Static Serving**: Express serves built frontend assets in production

### Database Management
- **Environment Variables**: DATABASE_URL for PostgreSQL connection
- **Migration System**: Drizzle Kit for schema updates and migrations
- **Connection Pooling**: Neon serverless PostgreSQL connection handling

### Mobile Optimization
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **PWA Ready**: Structured for potential Progressive Web App conversion
- **Performance**: Optimized bundle sizes and lazy loading capabilities

The application is designed to be easily deployable on platforms like Replit, Vercel, or similar hosting services with minimal configuration requirements.