# Hadal English - Google Play Store Deployment Guide

## Overview
This guide will help you deploy your Hadal English app to the Google Play Store using Progressive Web App (PWA) technology with Trusted Web Activity (TWA).

## Prerequisites ✅
- [x] Google Play Developer Account (verified)
- [x] PWA with HTTPS deployment
- [x] Web App Manifest
- [x] Service Worker

## Step 1: Install Required Tools

### Install Bubblewrap (Google's Official Tool)
```bash
npm install -g @bubblewrap/cli
```

### System Requirements
- Node.js 10 or above
- Java Development Kit (JDK) 8
- Android SDK

### Install Java JDK 8
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install openjdk-8-jdk

# macOS
brew install openjdk@8

# Windows
# Download from Oracle or use OpenJDK
```

### Install Android SDK
1. Download Android Studio: https://developer.android.com/studio
2. Install Android SDK through Android Studio
3. Set ANDROID_HOME environment variable

## Step 2: Deploy Your PWA

### Option A: Deploy to Replit (Recommended)
1. Your app is already deployed on Replit
2. Note your deployment URL: `https://your-repl-name.your-username.replit.app`
3. Ensure HTTPS is working

### Option B: Deploy to Vercel/Netlify
```bash
# Build your app
npm run build

# Deploy to Vercel
npx vercel --prod

# Or deploy to Netlify
npm install -g netlify-cli
netlify deploy --prod --dir=dist
```

## Step 3: Create App Icons

Create the following icon files in `client/public/`:

### Required Icons:
- `icon-192.png` (192x192 pixels)
- `icon-512.png` (512x512 pixels)

### Design Requirements:
- High-quality PNG format
- Transparent background or solid color
- Simple, recognizable design
- Represents your brand/app

### Suggested Icon Design:
Create icons with the Hadal English logo featuring:
- Book or speech bubble icon
- Blue and purple gradient colors
- "H" or "HE" text
- Clean, modern design

## Step 4: Set Up Digital Asset Links

### Create assetlinks.json
Create `.well-known/assetlinks.json` in your web root:

```json
[{
  "relation": ["delegate_permission/common.handle_all_urls"],
  "target": {
    "namespace": "android_app",
    "package_name": "com.hadalenglish.twa",
    "sha256_cert_fingerprints": ["YOUR_APP_FINGERPRINT_HERE"]
  }
}]
```

## Step 5: Initialize Bubblewrap Project

```bash
# Navigate to your project directory
cd /path/to/your/project

# Initialize Bubblewrap with your PWA manifest
bubblewrap init --manifest https://your-app-url.com/manifest.json
```

### Configuration Wizard:
Follow the prompts and provide:

- **Package Name**: `com.hadalenglish.twa`
- **App Name**: `Hadal English`
- **Display Name**: `Hadal English - Speak & Learn`
- **Theme Color**: `#3b82f6`
- **Background Color**: `#ffffff`
- **Start URL**: `/`
- **Icon URL**: Your 512x512 icon URL
- **Maskable Icon**: Yes (if available)

### Signing Key Setup:
When prompted for signing key:
- Choose to generate a new key
- Provide your details:
  - **Name**: Abdinur Mohamed Odowa
  - **Organization**: Hadal English
  - **Country**: Your country code
  - **Email**: odowaa1996@gmail.com

## Step 6: Build Android App Bundle

```bash
# Build the Android App Bundle
bubblewrap build
```

This generates:
- `app-release-bundle.aab` - Upload this to Google Play Store
- Signing key files (keep these secure!)

## Step 7: Update Digital Asset Links

1. Get the app fingerprint from the build output
2. Update your `.well-known/assetlinks.json` with the correct fingerprint
3. Deploy the updated file to your web server

## Step 7.5: Privacy Policy Setup

### Host Your Privacy Policy
Your privacy policy must be publicly accessible via HTTPS. Options:

1. **Use GitHub Pages (Free)**
   - Upload `PRIVACY_POLICY.md` to a GitHub repository
   - Enable GitHub Pages in repository settings
   - Your privacy policy URL will be: `https://username.github.io/repository-name/PRIVACY_POLICY.html`

2. **Use Google Sites (Free)**
   - Create a free Google Site
   - Copy the privacy policy content
   - Publish and get the public URL

3. **Host on Your Domain**
   - Upload to your website at `/privacy-policy.html`
   - Example: `https://yourdomain.com/privacy-policy.html`

### Privacy Policy URL Examples:
- `https://your-username.github.io/hadal-english/PRIVACY_POLICY.html`
- `https://sites.google.com/view/hadal-english-privacy`
- `https://your-repl-name.your-username.replit.app/privacy-policy`

## Step 8: Google Play Console Submission

### 1. Create New App
1. Go to [Google Play Console](https://play.google.com/console)
2. Click "Create app"
3. Fill in app details:
   - **App name**: Hadal English - Speak & Learn
   - **Default language**: English (United States)
   - **App or game**: App
   - **Free or paid**: Free

### 2. Complete App Content
Fill out the required sections:

#### App Access
- All functionality is available without restrictions

#### Ads
- Does your app contain ads? No (unless you plan to add them)

#### Content Rating
- Complete the content rating questionnaire
- Educational app for language learning

#### Target Audience
- Age group: 13+ (or appropriate for your content)
- Appeals to children: No

#### News Apps
- Not applicable

### 3. Store Listing
Provide:
- **App name**: Hadal English - Speak & Learn
- **Short description**: Learn English through practical lessons for Somali speakers
- **Full description**: 
```
Hadal English is a comprehensive language learning app designed specifically for Somali-speaking adults who want to improve their English skills. 

Key Features:
• Three progressive learning levels (Beginner, Intermediate, Advanced)
• Bilingual content with Somali translations
• Interactive voice practice and pronunciation guides
• Cultural context tips for real-world conversations
• Progress tracking and achievement system
• Offline capability for learning anywhere

Perfect for:
- Somali speakers learning English
- Students preparing for English proficiency tests
- Professionals improving workplace English
- Anyone interested in bilingual education

Download now and start your English learning journey with culturally sensitive, practical lessons!
```

- **App icon**: Upload your 512x512 icon
- **Feature graphic**: Create a 1024x500 promotional image
- **Screenshots**: Take 2-8 screenshots of your app in action

### 4. Upload App Bundle
1. Go to "Release" → "Production"
2. Click "Create new release"
3. Upload your `app-release-bundle.aab` file
4. Add release notes:
```
🎉 Initial release of Hadal English!

✓ Three learning levels with progressive difficulty
✓ Bilingual English-Somali content
✓ Voice practice and pronunciation guides
✓ Interactive quizzes and progress tracking
✓ Dark mode support
✓ Lesson reminders with voice alerts

Perfect for Somali speakers learning English!
```

### 5. Review and Publish
1. Complete all required sections
2. Save as draft
3. Review everything carefully
4. Submit for review

## Step 9: App Store Optimization (ASO)

### Keywords to Include:
- English learning
- Somali English
- Language learning
- ESL
- Pronunciation
- Bilingual education
- Adult learning
- Somalia English

### Categories:
- Primary: Education
- Secondary: Productivity

## Step 10: Testing Before Submission

1. Test your PWA thoroughly on different devices
2. Verify all features work offline
3. Check that the manifest loads correctly
4. Test voice features and audio playback
5. Verify dark mode works properly
6. Test lesson reminders functionality

## Timeline Expectations

- **App Review**: 1-3 days typically
- **First-time Developer**: May take longer
- **Updates**: Usually faster approval

## Post-Submission Checklist

After submission:
1. Monitor Google Play Console for review feedback
2. Respond to any policy violations quickly
3. Prepare marketing materials
4. Plan update schedule
5. Monitor user reviews and ratings

## Contact Information for Support

For deployment assistance:
- **Developer**: Abdinur Mohamed Odowa
- **WhatsApp**: +252616538992
- **Email**: odowaa1996@gmail.com

## Additional Resources

- [Google Play Console](https://play.google.com/console)
- [Bubblewrap Documentation](https://github.com/GoogleChromeLabs/bubblewrap)
- [TWA Documentation](https://developers.google.com/web/android/trusted-web-activity)
- [PWA Guidelines](https://web.dev/progressive-web-apps/)

---

**Good luck with your Google Play Store deployment! 🚀**

The Hadal English app is well-designed and should provide great value to Somali speakers learning English.