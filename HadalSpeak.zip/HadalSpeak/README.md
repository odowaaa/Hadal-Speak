# Hadal English - Learn English for Somali Speakers

A mobile-first English learning application designed specifically for Somali-speaking adults. Learn English through practical daily-life lessons with bilingual content, interactive quizzes, and voice practice.

## Features

- **Three Learning Levels**: Beginner, Intermediate, and Advanced
- **Bilingual Content**: English-Somali translations and cultural context
- **Voice Practice**: Pronunciation guides with speech recognition
- **Interactive Quizzes**: Progress tracking and immediate feedback
- **Dark Mode**: Complete theme support with smooth transitions
- **PWA Ready**: Works offline and can be installed on mobile devices
- **Lesson Reminders**: Voice alerts in both English and Somali

## Technology Stack

- **Frontend**: React 18 + TypeScript + Vite
- **UI Framework**: Shadcn/UI + Radix UI + Tailwind CSS
- **Backend**: Node.js + Express + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **State Management**: TanStack Query (React Query)
- **Mobile**: PWA with service worker and offline support

## Getting Started

### Prerequisites
- Node.js 18 or higher
- PostgreSQL database

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/hadal-english.git
cd hadal-english
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
# Database connection (required)
DATABASE_URL=your_postgresql_connection_string
```

4. Start the development server:
```bash
npm run dev
```

The app will be available at `http://localhost:5000`

## Building for Production

```bash
npm run build
npm run start
```

## Google Play Store Deployment

This app is ready for Google Play Store deployment as a PWA (Progressive Web App) using Trusted Web Activity (TWA).

### Quick Deployment Steps:
1. Deploy your app to get HTTPS URL
2. Install Bubblewrap: `npm install -g @bubblewrap/cli`
3. Generate Android App Bundle: `bubblewrap init --manifest https://your-url/manifest.json`
4. Build: `bubblewrap build`
5. Upload the generated `.aab` file to Google Play Console

See `GOOGLE_PLAY_DEPLOYMENT_GUIDE.md` for detailed instructions.

## Privacy Policy

A comprehensive privacy policy is included that complies with:
- Google Play Store requirements
- GDPR (General Data Protection Regulation)
- CCPA (California Consumer Privacy Act)

Privacy policy is available at `/privacy-policy` route and as `PRIVACY_POLICY.md`.

## Learning Content

The app includes three progressive levels:

### Level 1 - Beginner (Bilcaabitaanka)
- Basic greetings and introductions
- Numbers and time
- Essential daily phrases
- Family and personal information

### Level 2 - Intermediate (Dhexdhexaadka)
- Workplace conversations
- Shopping and daily activities
- Past and future tense usage
- Cultural context integration

### Level 3 - Advanced (Horumarsan)
- Professional communication
- Complex storytelling
- Formal and informal registers
- Advanced grammar structures

## Developer

**Abdinur Mohamed Odowa**
- Email: odowaa1996@gmail.com
- WhatsApp: +252616538992

## License

MIT License - see LICENSE file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Support

For support or questions about the app, please contact:
- Email: odowaa1996@gmail.com
- WhatsApp: +252616538992

---

Made with ❤️ for the Somali community learning English