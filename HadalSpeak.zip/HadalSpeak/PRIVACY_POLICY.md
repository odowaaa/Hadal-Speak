# Privacy Policy for Hadal English

**Effective Date:** January 30, 2025  
**Last Updated:** January 30, 2025

## Introduction

Hadal English ("we," "our," or "us") operates the Hadal English mobile application (the "Service"). This page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data.

## Information We Collect

### Personal Information
We may collect the following types of personal information:
- **Account Information:** Username and language preferences
- **Learning Progress:** Lesson completion status, quiz scores, and study streaks
- **Audio Recordings:** Voice recordings for pronunciation practice (stored locally on your device)
- **Usage Analytics:** App usage patterns to improve learning experience

### Automatically Collected Information
- **Device Information:** Device type, operating system, and app version
- **Usage Data:** Features used, time spent in app, and lesson interactions
- **Technical Data:** IP address, browser type, and access times (for web version)

## How We Use Your Information

We use the collected information for the following purposes:
- **Educational Services:** To provide personalized language learning experiences
- **Progress Tracking:** To save and sync your learning progress across devices
- **App Improvement:** To analyze usage patterns and improve our educational content
- **Communication:** To send lesson reminders and important app updates
- **Technical Support:** To provide customer support and troubleshoot issues

## Data Storage and Security

### Local Storage
- Learning progress and preferences are stored locally on your device
- Voice recordings for pronunciation practice remain on your device
- Offline functionality ensures learning continues without internet connection

### Cloud Storage
- Progress synchronization data may be stored securely in cloud databases
- All data transmission is encrypted using industry-standard SSL/TLS protocols
- We implement appropriate security measures to protect against unauthorized access

## Third-Party Services

Our app may use third-party services that may collect information:
- **Google Play Services:** For app distribution and analytics
- **Web Speech API:** For text-to-speech functionality (processed locally)
- **Analytics Services:** To understand app usage and improve user experience

## Children's Privacy

Hadal English is designed for users aged 13 and above. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe your child has provided personal information, please contact us to have it removed.

## Your Rights and Choices

You have the following rights regarding your personal data:
- **Access:** Request access to your personal data
- **Correction:** Request correction of inaccurate personal data
- **Deletion:** Request deletion of your personal data
- **Portability:** Request a copy of your data in a structured format
- **Opt-out:** Disable data collection through app settings

### How to Exercise Your Rights
- Use in-app settings to manage preferences
- Contact us directly at odowaa1996@gmail.com
- Reset your progress through the app's profile section

## Data Retention

- **Learning Progress:** Retained until you delete your account or reset progress
- **Analytics Data:** Anonymized and retained for up to 2 years
- **Voice Recordings:** Stored locally on your device only
- **Account Data:** Deleted within 30 days of account deletion request

## International Data Transfers

If you are located outside Somalia, your information may be transferred to and processed in countries where our service providers are located. We ensure appropriate safeguards are in place for such transfers.

## Cookies and Tracking

Our web version may use cookies for:
- **Essential Functions:** App functionality and user preferences
- **Analytics:** Understanding user behavior (anonymized)
- **Performance:** Improving app loading and responsiveness

You can manage cookie preferences through your browser settings.

## Updates to This Policy

We may update this Privacy Policy from time to time. We will notify you of any changes by:
- Posting the new Privacy Policy in the app
- Sending an in-app notification
- Updating the "Last Updated" date at the top of this policy

Continued use of the app after changes constitutes acceptance of the updated policy.

## Contact Information

If you have any questions about this Privacy Policy or our data practices, please contact us:

**Developer:** Abdinur Mohamed Odowa  
**Email:** odowaa1996@gmail.com  
**WhatsApp:** +252616538992  
**App:** Hadal English - Profile Section

## Legal Basis for Processing (GDPR)

For users in the European Union, our legal basis for processing personal data includes:
- **Consent:** For optional features like analytics
- **Contract Performance:** For providing educational services
- **Legitimate Interest:** For app improvement and security

## California Privacy Rights (CCPA)

California residents have additional rights under the California Consumer Privacy Act:
- Right to know what personal information is collected
- Right to delete personal information
- Right to opt-out of the sale of personal information (we do not sell personal data)
- Right to non-discrimination for exercising privacy rights

## Compliance

This privacy policy complies with:
- General Data Protection Regulation (GDPR)
- California Consumer Privacy Act (CCPA)
- Google Play Store requirements
- Apple App Store guidelines (if applicable)

## Data Protection Officer

For GDPR-related inquiries, contact our Data Protection Officer:
**Email:** odowaa1996@gmail.com
**Subject Line:** "GDPR/Privacy Inquiry - Hadal English"

---

**Note:** This privacy policy is designed to be transparent and user-friendly while meeting legal requirements for app store publication and international data protection laws.