import { type User, type InsertUser, type Lesson, type InsertLesson, type UserProgress, type InsertUserProgress, type QuizQuestion, type InsertQuizQuestion, users, lessons, userProgress, quizQuestions } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getLessonsByLevel(level: number): Promise<Lesson[]>;
  getLesson(id: string): Promise<Lesson | undefined>;
  createLesson(lesson: InsertLesson): Promise<Lesson>;
  
  getUserProgress(userId: string): Promise<UserProgress[]>;
  getLessonProgress(userId: string, lessonId: string): Promise<UserProgress | undefined>;
  updateUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  
  getQuizQuestions(lessonId: string): Promise<QuizQuestion[]>;
  createQuizQuestion(question: InsertQuizQuestion): Promise<QuizQuestion>;
  
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private lessons: Map<string, Lesson>;
  private userProgress: Map<string, UserProgress>;
  private quizQuestions: Map<string, QuizQuestion>;

  constructor() {
    this.users = new Map();
    this.lessons = new Map();
    this.userProgress = new Map();
    this.quizQuestions = new Map();
    this.initializeData();
  }

  private initializeData() {
    // Initialize with sample lesson data
    const lessonsData = [
      // Level 1 - Beginner
      { level: 1, lessonNumber: 1, title: "Greetings", english: "Hello! How are you?", somali: "Nabad! Sidee tahay?", keyWords: { "Hello": "Nabad", "You": "Adiga", "How": "Sidee", "Are": "Tahay" } },
      { level: 1, lessonNumber: 2, title: "Introducing Yourself", english: "My name is Amina. I am from Somalia.", somali: "Magacaygu waa Amina. Waxaan ka imid Soomaaliya.", keyWords: { "My": "Kayga", "Name": "Magac", "From": "Ka", "Somalia": "Soomaaliya" } },
      { level: 1, lessonNumber: 3, title: "Asking for Help", english: "Please help me.", somali: "Fadlan i caawi.", keyWords: { "Please": "Fadlan", "Help": "Caawi", "Me": "I" } },
      { level: 1, lessonNumber: 4, title: "Buying Food", english: "I want to buy bread and milk.", somali: "Waxaan rabaa inaan iibsado rooti iyo caano.", keyWords: { "Want": "Rabaa", "Buy": "Iibsado", "Bread": "Rooti", "Milk": "Caano" } },
      { level: 1, lessonNumber: 5, title: "Numbers & Time", english: "It is 5 o'clock.", somali: "Waa shan saac.", keyWords: { "Five": "Shan", "Clock": "Saac", "Time": "Waqti" } },
      { level: 1, lessonNumber: 6, title: "At Home", english: "This is my house.", somali: "Tani waa gurigayga.", keyWords: { "This": "Tani", "House": "Guri", "My": "Kayga" } },
      { level: 1, lessonNumber: 7, title: "Days of the Week", english: "Today is Monday.", somali: "Maanta waa Isniin.", keyWords: { "Today": "Maanta", "Monday": "Isniin", "Day": "Maalin" } },
      
      // Level 2 - Intermediate
      { level: 2, lessonNumber: 1, title: "At the Clinic", english: "I have a headache. I need to see a doctor.", somali: "Madaxa ayaa i xanuunaya. Waxaan u baahanahay inaan arko dhakhtar.", keyWords: { "Headache": "Madax xanuun", "Doctor": "Dhakhtar", "Need": "U baahan" } },
      { level: 2, lessonNumber: 2, title: "Asking Directions", english: "Where is the market?", somali: "Suuqii xaggee ku yaal?", keyWords: { "Where": "Xaggee", "Market": "Suuq", "Located": "Ku yaal" } },
      { level: 2, lessonNumber: 3, title: "At the Workplace", english: "I am working in an office.", somali: "Waxaan ka shaqeeyaa xafiis.", keyWords: { "Working": "Shaqeeyaa", "Office": "Xafiis", "Job": "Shaqo" } },
      { level: 2, lessonNumber: 4, title: "Talking About Weather", english: "It is hot today.", somali: "Maanta waa kulayl.", keyWords: { "Hot": "Kulayl", "Weather": "Cimilo", "Today": "Maanta" } },
      { level: 2, lessonNumber: 5, title: "Visiting Someone", english: "I am coming to visit you tomorrow.", somali: "Berri ayaan kuu imaanayaa booqasho.", keyWords: { "Visit": "Booqasho", "Tomorrow": "Berri", "Coming": "Imaanayaa" } },
      { level: 2, lessonNumber: 6, title: "Shopping", english: "How much does this cost?", somali: "Imisa ayuu kani ku kacayaa?", keyWords: { "How much": "Imisa", "Cost": "Ku kacayaa", "Price": "Qiimo" } },
      { level: 2, lessonNumber: 7, title: "Calling a Taxi", english: "I need a taxi to go to the hospital.", somali: "Waxaan u baahanahay taksi aan ku tago isbitaalka.", keyWords: { "Taxi": "Taksi", "Hospital": "Isbitaal", "Go": "Tago" } },
      
      // Level 3 - Advanced
      { level: 3, lessonNumber: 1, title: "Expressing Opinions", english: "I think education is very important.", somali: "Waxaan u maleynayaa in waxbarashadu aad muhiim u tahay.", keyWords: { "Think": "U maleynayaa", "Education": "Waxbarash", "Important": "Muhiim" } },
      { level: 3, lessonNumber: 2, title: "Applying for a Job", english: "I would like to apply for this job because I have experience.", somali: "Waxaan jeclaan lahaa inaan codsado shaqadan sababtoo ah waayo-aragnimo ayaan leeyahay.", keyWords: { "Apply": "Codsado", "Experience": "Waayo-aragnimo", "Because": "Sababtoo ah" } },
      { level: 3, lessonNumber: 3, title: "Solving a Problem", english: "We need to find a solution together.", somali: "Waa inaan helnaa xal aan wada leenahay.", keyWords: { "Solution": "Xal", "Together": "Wada", "Problem": "Dhibaato" } },
      { level: 3, lessonNumber: 4, title: "Telling a Story", english: "Last year, I traveled to Mogadishu and met many people.", somali: "Sanadkii hore, waxaan u safray Muqdisho oo dad badan ayaan la kulmay.", keyWords: { "Last year": "Sanadkii hore", "Traveled": "U safray", "Met": "La kulmay" } },
      { level: 3, lessonNumber: 5, title: "Talking About Feelings", english: "I feel happy when I help others.", somali: "Waan farxaa markaan dadka kale caawiyo.", keyWords: { "Feel": "Farxaa", "Happy": "Farxad", "Help": "Caawiyo" } },
      { level: 3, lessonNumber: 6, title: "Describing a Problem", english: "There is a water leak in the kitchen.", somali: "Waxaa jira biyaha oo daadanaya jikada.", keyWords: { "Water": "Biyaha", "Leak": "Daadanaya", "Kitchen": "Jikada" } },
      { level: 3, lessonNumber: 7, title: "Making a Suggestion", english: "Let's meet at 4 o'clock to discuss the plan.", somali: "Aan isugu nimaadno afarta si aan uga hadalno qorshaha.", keyWords: { "Meet": "Isugu nimaadno", "Discuss": "Uga hadalno", "Plan": "Qorshaha" } }
    ];

    lessonsData.forEach(lessonData => {
      const lesson: Lesson = {
        id: randomUUID(),
        level: lessonData.level,
        lessonNumber: lessonData.lessonNumber,
        title: lessonData.title,
        english: lessonData.english,
        somali: lessonData.somali,
        keyWords: lessonData.keyWords
      };
      this.lessons.set(lesson.id, lesson);

      // Add sample quiz questions for each lesson
      const keywordEntries = Object.entries(lessonData.keyWords);
      if (keywordEntries.length > 0) {
        const [englishWord, somaliWord] = keywordEntries[0];
        const quizQuestion: QuizQuestion = {
          id: randomUUID(),
          lessonId: lesson.id,
          question: `How do you say "${englishWord}" in Somali?`,
          options: [
            somaliWord,
            "Wrong answer 1",
            "Wrong answer 2"
          ],
          correctAnswer: 0
        };
        this.quizQuestions.set(quizQuestion.id, quizQuestion);
      }
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      id,
      username: insertUser.username,
      password: insertUser.password,
      language: insertUser.language || 'en',
      streak: insertUser.streak || 0,
      overallProgress: insertUser.overallProgress || 0
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getLessonsByLevel(level: number): Promise<Lesson[]> {
    return Array.from(this.lessons.values()).filter(lesson => lesson.level === level);
  }

  async getLesson(id: string): Promise<Lesson | undefined> {
    return this.lessons.get(id);
  }

  async createLesson(insertLesson: InsertLesson): Promise<Lesson> {
    const id = randomUUID();
    const lesson: Lesson = { ...insertLesson, id };
    this.lessons.set(id, lesson);
    return lesson;
  }

  async getUserProgress(userId: string): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(progress => progress.userId === userId);
  }

  async getLessonProgress(userId: string, lessonId: string): Promise<UserProgress | undefined> {
    return Array.from(this.userProgress.values()).find(
      progress => progress.userId === userId && progress.lessonId === lessonId
    );
  }

  async updateUserProgress(progressData: InsertUserProgress): Promise<UserProgress> {
    const existing = await this.getLessonProgress(progressData.userId, progressData.lessonId);
    
    if (existing) {
      const updated = { ...existing, ...progressData };
      this.userProgress.set(existing.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const progress: UserProgress = { 
        id,
        userId: progressData.userId,
        lessonId: progressData.lessonId,
        completed: progressData.completed || false,
        quizScore: progressData.quizScore || null,
        completedAt: progressData.completedAt || null
      };
      this.userProgress.set(id, progress);
      return progress;
    }
  }

  async getQuizQuestions(lessonId: string): Promise<QuizQuestion[]> {
    return Array.from(this.quizQuestions.values()).filter(question => question.lessonId === lessonId);
  }

  async createQuizQuestion(insertQuestion: InsertQuizQuestion): Promise<QuizQuestion> {
    const id = randomUUID();
    const question: QuizQuestion = { ...insertQuestion, id };
    this.quizQuestions.set(id, question);
    return question;
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getLessonsByLevel(level: number): Promise<Lesson[]> {
    return await db.select().from(lessons).where(eq(lessons.level, level));
  }

  async getLesson(id: string): Promise<Lesson | undefined> {
    const [lesson] = await db.select().from(lessons).where(eq(lessons.id, id));
    return lesson || undefined;
  }

  async createLesson(insertLesson: InsertLesson): Promise<Lesson> {
    const [lesson] = await db
      .insert(lessons)
      .values(insertLesson)
      .returning();
    return lesson;
  }

  async getUserProgress(userId: string): Promise<UserProgress[]> {
    return await db.select().from(userProgress).where(eq(userProgress.userId, userId));
  }

  async getLessonProgress(userId: string, lessonId: string): Promise<UserProgress | undefined> {
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(eq(userProgress.userId, userId))
      .where(eq(userProgress.lessonId, lessonId));
    return progress || undefined;
  }

  async updateUserProgress(progressData: InsertUserProgress): Promise<UserProgress> {
    const existing = await this.getLessonProgress(progressData.userId, progressData.lessonId);
    
    if (existing) {
      const [updated] = await db
        .update(userProgress)
        .set(progressData)
        .where(eq(userProgress.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(userProgress)
        .values(progressData)
        .returning();
      return created;
    }
  }

  async getQuizQuestions(lessonId: string): Promise<QuizQuestion[]> {
    return await db.select().from(quizQuestions).where(eq(quizQuestions.lessonId, lessonId));
  }

  async createQuizQuestion(insertQuestion: InsertQuizQuestion): Promise<QuizQuestion> {
    const [question] = await db
      .insert(quizQuestions)
      .values(insertQuestion)
      .returning();
    return question;
  }

  async initializeData(): Promise<void> {
    // Check if data already exists
    const existingLessons = await db.select().from(lessons).limit(1);
    if (existingLessons.length > 0) {
      return; // Data already initialized
    }

    // Initialize with sample lesson data
    const lessonsData = [
      // Level 1 - Beginner
      { level: 1, lessonNumber: 1, title: "Greetings", english: "Hello! How are you?", somali: "Nabad! Sidee tahay?", keyWords: { "Hello": "Nabad", "You": "Adiga", "How": "Sidee", "Are": "Tahay" } },
      { level: 1, lessonNumber: 2, title: "Introducing Yourself", english: "My name is Amina. I am from Somalia.", somali: "Magacaygu waa Amina. Waxaan ka imid Soomaaliya.", keyWords: { "My": "Kayga", "Name": "Magac", "From": "Ka", "Somalia": "Soomaaliya" } },
      { level: 1, lessonNumber: 3, title: "Asking for Help", english: "Please help me.", somali: "Fadlan i caawi.", keyWords: { "Please": "Fadlan", "Help": "Caawi", "Me": "I" } },
      { level: 1, lessonNumber: 4, title: "Buying Food", english: "I want to buy bread and milk.", somali: "Waxaan rabaa inaan iibsado rooti iyo caano.", keyWords: { "Want": "Rabaa", "Buy": "Iibsado", "Bread": "Rooti", "Milk": "Caano" } },
      { level: 1, lessonNumber: 5, title: "Numbers & Time", english: "It is 5 o'clock.", somali: "Waa shan saac.", keyWords: { "Five": "Shan", "Clock": "Saac", "Time": "Waqti" } },
      { level: 1, lessonNumber: 6, title: "At Home", english: "This is my house.", somali: "Tani waa gurigayga.", keyWords: { "This": "Tani", "House": "Guri", "My": "Kayga" } },
      { level: 1, lessonNumber: 7, title: "Days of the Week", english: "Today is Monday.", somali: "Maanta waa Isniin.", keyWords: { "Today": "Maanta", "Monday": "Isniin", "Day": "Maalin" } },
      
      // Level 2 - Intermediate
      { level: 2, lessonNumber: 1, title: "At the Clinic", english: "I have a headache. I need to see a doctor.", somali: "Madaxa ayaa i xanuunaya. Waxaan u baahanahay inaan arko dhakhtar.", keyWords: { "Headache": "Madax xanuun", "Doctor": "Dhakhtar", "Need": "U baahan" } },
      { level: 2, lessonNumber: 2, title: "Asking Directions", english: "Where is the market?", somali: "Suuqii xaggee ku yaal?", keyWords: { "Where": "Xaggee", "Market": "Suuq", "Located": "Ku yaal" } },
      { level: 2, lessonNumber: 3, title: "At the Workplace", english: "I am working in an office.", somali: "Waxaan ka shaqeeyaa xafiis.", keyWords: { "Working": "Shaqeeyaa", "Office": "Xafiis", "Job": "Shaqo" } },
      { level: 2, lessonNumber: 4, title: "Talking About Weather", english: "It is hot today.", somali: "Maanta waa kulayl.", keyWords: { "Hot": "Kulayl", "Weather": "Cimilo", "Today": "Maanta" } },
      { level: 2, lessonNumber: 5, title: "Visiting Someone", english: "I am coming to visit you tomorrow.", somali: "Berri ayaan kuu imaanayaa booqasho.", keyWords: { "Visit": "Booqasho", "Tomorrow": "Berri", "Coming": "Imaanayaa" } },
      { level: 2, lessonNumber: 6, title: "Shopping", english: "How much does this cost?", somali: "Imisa ayuu kani ku kacayaa?", keyWords: { "How much": "Imisa", "Cost": "Ku kacayaa", "Price": "Qiimo" } },
      { level: 2, lessonNumber: 7, title: "Calling a Taxi", english: "I need a taxi to go to the hospital.", somali: "Waxaan u baahanahay taksi aan ku tago isbitaalka.", keyWords: { "Taxi": "Taksi", "Hospital": "Isbitaal", "Go": "Tago" } },
      
      // Level 3 - Advanced
      { level: 3, lessonNumber: 1, title: "Expressing Opinions", english: "I think education is very important.", somali: "Waxaan u maleynayaa in waxbarashadu aad muhiim u tahay.", keyWords: { "Think": "U maleynayaa", "Education": "Waxbarash", "Important": "Muhiim" } },
      { level: 3, lessonNumber: 2, title: "Applying for a Job", english: "I would like to apply for this job because I have experience.", somali: "Waxaan jeclaan lahaa inaan codsado shaqadan sababtoo ah waayo-aragnimo ayaan leeyahay.", keyWords: { "Apply": "Codsado", "Experience": "Waayo-aragnimo", "Because": "Sababtoo ah" } },
      { level: 3, lessonNumber: 3, title: "Solving a Problem", english: "We need to find a solution together.", somali: "Waa inaan helnaa xal aan wada leenahay.", keyWords: { "Solution": "Xal", "Together": "Wada", "Problem": "Dhibaato" } },
      { level: 3, lessonNumber: 4, title: "Telling a Story", english: "Last year, I traveled to Mogadishu and met many people.", somali: "Sanadkii hore, waxaan u safray Muqdisho oo dad badan ayaan la kulmay.", keyWords: { "Last year": "Sanadkii hore", "Traveled": "U safray", "Met": "La kulmay" } },
      { level: 3, lessonNumber: 5, title: "Talking About Feelings", english: "I feel happy when I help others.", somali: "Waan farxaa markaan dadka kale caawiyo.", keyWords: { "Feel": "Farxaa", "Happy": "Farxad", "Help": "Caawiyo" } },
      { level: 3, lessonNumber: 6, title: "Describing a Problem", english: "There is a water leak in the kitchen.", somali: "Waxaa jira biyaha oo daadanaya jikada.", keyWords: { "Water": "Biyaha", "Leak": "Daadanaya", "Kitchen": "Jikada" } },
      { level: 3, lessonNumber: 7, title: "Making a Suggestion", english: "Let's meet at 4 o'clock to discuss the plan.", somali: "Aan isugu nimaadno afarta si aan uga hadalno qorshaha.", keyWords: { "Meet": "Isugu nimaadno", "Discuss": "Uga hadalno", "Plan": "Qorshaha" } }
    ];

    for (const lessonData of lessonsData) {
      const [lesson] = await db
        .insert(lessons)
        .values(lessonData)
        .returning();

      // Add sample quiz questions for each lesson
      const keywordEntries = Object.entries(lessonData.keyWords);
      if (keywordEntries.length > 0) {
        const [englishWord, somaliWord] = keywordEntries[0];
        await db
          .insert(quizQuestions)
          .values({
            lessonId: lesson.id,
            question: `How do you say "${englishWord}" in Somali?`,
            options: [
              somaliWord,
              "Wrong answer 1",
              "Wrong answer 2"
            ],
            correctAnswer: 0
          });
      }
    }
  }
}

export const storage = new DatabaseStorage();
