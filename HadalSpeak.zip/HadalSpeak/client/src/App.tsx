import { useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "./pages/home";
import Lesson from "./pages/lesson";
import Lessons from "./pages/lessons";
import Practice from "./pages/practice";
import Progress from "./pages/progress";
import Profile from "./pages/profile";
import PrivacyPolicy from "./pages/privacy-policy";
import NotFound from "./pages/not-found";
import NotificationReminder from "./components/notification-reminder";
import { useLessonReminders } from "./hooks/use-lesson-reminders";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/lessons" component={Lessons} />
      <Route path="/lesson/:level/:lessonId" component={Lesson} />
      <Route path="/practice" component={Practice} />
      <Route path="/progress" component={Progress} />
      <Route path="/profile" component={Profile} />
      <Route path="/privacy-policy" component={PrivacyPolicy} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [currentUser] = useState({ 
    language: 'en' as 'en' | 'so'
  });

  const {
    showReminder,
    dismissReminder,
    snoozeReminder,
    markLessonCompleted
  } = useLessonReminders();

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
        
        {/* Lesson Reminder Notification */}
        {showReminder && (
          <NotificationReminder
            language={currentUser.language}
            onClose={dismissReminder}
            onSnooze={snoozeReminder}
          />
        )}
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
