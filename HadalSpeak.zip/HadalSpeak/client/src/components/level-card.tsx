import { Card } from "@/components/ui/card";
import { Lock, ChevronRight } from "lucide-react";

interface LevelCardProps {
  level: number;
  title: string;
  description: string;
  icon: string;
  progress: number;
  completedLessons: number;
  totalLessons: number;
  bgColor: string;
  iconColor: string;
  progressColor: string;
  badgeColor: string;
  isLocked: boolean;
  onSelect: () => void;
  language: string;
}

export default function LevelCard({
  title,
  description,
  icon,
  progress,
  completedLessons,
  totalLessons,
  bgColor,
  iconColor,
  progressColor,
  badgeColor,
  isLocked,
  onSelect,
  language
}: LevelCardProps) {
  return (
    <Card 
      className={`p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow cursor-pointer ${isLocked ? 'opacity-75' : ''}`}
      onClick={!isLocked ? onSelect : undefined}
    >
      <div className="flex items-start space-x-4">
        <div className="flex-shrink-0">
          <div className={`w-12 h-12 ${bgColor} rounded-xl flex items-center justify-center`}>
            {isLocked ? (
              <Lock className={`${iconColor} h-5 w-5`} />
            ) : (
              <i className={`${icon} ${iconColor} text-lg`}></i>
            )}
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
            {isLocked ? (
              <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded-full font-medium">
                {language === 'en' ? 'Locked' : 'Xiran'}
              </span>
            ) : (
              <span className={`text-xs px-2 py-1 ${badgeColor} rounded-full font-medium`}>
                {completedLessons}/{totalLessons} {language === 'en' ? 'Complete' : 'Dhammaan'}
              </span>
            )}
          </div>
          <p className="text-sm text-gray-600 mb-3">{description}</p>
          <div className="flex items-center space-x-4 text-xs text-gray-500">
            <span>
              <i className="fas fa-clock mr-1"></i>
              {language === 'en' ? '5-15 min/lesson' : '5-15 daqiiqo/cashar'}
            </span>
          </div>
          <div className="mt-3 w-full bg-gray-200 rounded-full h-1.5">
            <div 
              className={`${progressColor} h-1.5 rounded-full transition-all duration-300`}
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
        {isLocked ? (
          <Lock className="text-gray-400 mt-2 h-4 w-4" />
        ) : (
          <ChevronRight className="text-gray-400 mt-2 h-4 w-4" />
        )}
      </div>
    </Card>
  );
}
