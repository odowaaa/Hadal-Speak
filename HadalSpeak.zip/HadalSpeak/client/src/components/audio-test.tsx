import { useState } from "react";
import { Volume2, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function AudioTest() {
  const [testResult, setTestResult] = useState<string>('');
  
  const testAudio = () => {
    setTestResult('Testing...');
    
    if (!('speechSynthesis' in window)) {
      setTestResult('❌ Speech synthesis not supported in this browser');
      return;
    }
    
    // Test basic audio
    const utterance = new SpeechSynthesisUtterance('Hello, this is a test');
    utterance.lang = 'en-US';
    utterance.rate = 0.8;
    utterance.volume = 1.0;
    
    utterance.onstart = () => {
      setTestResult('✅ Audio is working! Playing test sound...');
    };
    
    utterance.onend = () => {
      setTestResult('✅ Audio test completed successfully');
    };
    
    utterance.onerror = (event) => {
      setTestResult(`❌ Audio error: ${event.error}`);
    };
    
    try {
      window.speechSynthesis.speak(utterance);
    } catch (error) {
      setTestResult(`❌ Failed to play audio: ${error}`);
    }
  };
  
  const showVoices = () => {
    const voices = window.speechSynthesis.getVoices();
    console.log('Available voices:', voices);
    setTestResult(`Found ${voices.length} voices. Check console for details.`);
  };
  
  return (
    <Card className="p-4 m-4 bg-yellow-50 border-yellow-200">
      <h3 className="text-lg font-semibold text-yellow-800 mb-3">Audio System Test</h3>
      
      <div className="space-y-3">
        <div className="flex space-x-2">
          <Button onClick={testAudio} size="sm">
            <Play className="h-4 w-4 mr-2" />
            Test Audio
          </Button>
          <Button onClick={showVoices} variant="outline" size="sm">
            Show Voices
          </Button>
        </div>
        
        {testResult && (
          <div className="p-3 bg-white rounded-lg border">
            <p className="text-sm">{testResult}</p>
          </div>
        )}
      </div>
    </Card>
  );
}