import { CheckCircle, Star, Trophy, ArrowRight } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface LessonCompletionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNext: () => void;
  score: number;
  perfectScore: boolean;
  language: 'en' | 'so';
  encouragementMessage?: string;
}

export default function LessonCompletionModal({
  isOpen,
  onClose,
  onNext,
  score,
  perfectScore,
  language,
  encouragementMessage
}: LessonCompletionModalProps) {
  if (!isOpen) return null;

  const getEncouragementMessage = () => {
    if (encouragementMessage) return encouragementMessage;
    
    if (perfectScore) {
      return language === 'en' 
        ? 'Perfect! You mastered this lesson!'
        : 'Heer sare! Waxaad si fiican u bartay casharkan!';
    } else if (score >= 80) {
      return language === 'en'
        ? 'Great job! You\'re learning well!'
        : 'Shaqo wanaagsan! Si fiican ayaad u baraysaa!';
    } else if (score >= 60) {
      return language === 'en'
        ? 'Good effort! Keep practicing!'
        : 'Dadaal wanaagsan! Sii wad ku celcelinta!';
    } else {
      return language === 'en'
        ? 'Keep going! Practice makes perfect!'
        : 'Sii wad! Ku celcelinu waa kaamilnimo!';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-sm bg-white p-6 text-center space-y-6">
        {/* Success Icon */}
        <div className="flex justify-center">
          <div className={`w-20 h-20 rounded-full flex items-center justify-center ${
            perfectScore 
              ? 'bg-gradient-to-r from-yellow-400 to-orange-400' 
              : score >= 70
              ? 'bg-gradient-to-r from-green-400 to-blue-400'
              : 'bg-gradient-to-r from-blue-400 to-purple-400'
          }`}>
            {perfectScore ? (
              <Trophy className="h-10 w-10 text-white" />
            ) : (
              <CheckCircle className="h-10 w-10 text-white" />
            )}
          </div>
        </div>

        {/* Score Display */}
        <div className="space-y-2">
          <h2 className="text-xl font-bold text-gray-900">
            {language === 'en' ? 'Lesson Complete!' : 'Casharku waa dhamaday!'}
          </h2>
          
          <div className="flex items-center justify-center space-x-2">
            <span className="text-3xl font-bold text-gray-900">{score}%</span>
            {perfectScore && (
              <div className="flex space-x-1">
                {[...Array(3)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-500 fill-current" />
                ))}
              </div>
            )}
          </div>
          
          <p className="text-gray-600 text-sm">
            {getEncouragementMessage()}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button 
            onClick={onNext} 
            className="w-full"
            size="lg"
          >
            <ArrowRight className="h-4 w-4 mr-2" />
            {language === 'en' ? 'Next Lesson' : 'Casharka Xiga'}
          </Button>
          
          <Button 
            onClick={onClose} 
            variant="outline" 
            className="w-full"
          >
            {language === 'en' ? 'Continue Practicing' : 'Sii wad ku celcelinta'}
          </Button>
        </div>

        {/* Progress Indicator */}
        <div className="text-xs text-gray-500">
          {language === 'en'
            ? 'Your progress has been saved automatically'
            : 'Horumaarkaagu si toos ah ayaa loo keydiyay'
          }
        </div>
      </Card>
    </div>
  );
}