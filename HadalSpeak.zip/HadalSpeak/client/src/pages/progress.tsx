import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { ArrowLeft, Trophy, Target, TrendingUp, Calendar, Award, BookOpen, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Header from "../components/header";
import BottomNav from "../components/bottom-nav";
import StudyStreak from "../components/study-streak";
import LessonProgressBar from "../components/lesson-progress-bar";
import { Lesson, UserProgress } from "@shared/schema";

export default function Progress() {
  const [, setLocation] = useLocation();
  const [currentUser] = useState({ 
    id: 'demo-user', 
    username: 'demo', 
    language: 'en' as 'en' | 'so',
    streak: 5,
    overallProgress: 0
  });

  // Get lessons for each level
  const { data: level1Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/level/1"]
  });

  const { data: level2Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/level/2"]
  });

  const { data: level3Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/level/3"]
  });

  const { data: userProgress = [] } = useQuery<UserProgress[]>({
    queryKey: ["/api/progress", currentUser.id]
  });

  // Calculate progress statistics
  const totalLessons = level1Lessons.length + level2Lessons.length + level3Lessons.length;
  const completedLessons = userProgress.filter(p => p.completed).length;
  const overallProgress = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;

  const getProgressForLevel = (lessons: Lesson[]) => {
    if (lessons.length === 0) return 0;
    const completedCount = lessons.filter(lesson => 
      userProgress.some(p => p.lessonId === lesson.id && p.completed)
    ).length;
    return Math.round((completedCount / lessons.length) * 100);
  };

  const level1Progress = getProgressForLevel(level1Lessons);
  const level2Progress = getProgressForLevel(level2Lessons);
  const level3Progress = getProgressForLevel(level3Lessons);

  const averageQuizScore = userProgress.length > 0 
    ? Math.round(userProgress.reduce((acc, p) => acc + (p.quizScore || 0), 0) / userProgress.length)
    : 0;

  const recentCompletions = userProgress
    .filter(p => p.completed && p.completedAt)
    .sort((a, b) => new Date(b.completedAt!).getTime() - new Date(a.completedAt!).getTime())
    .slice(0, 3);

  const toggleLanguage = () => {
    // Implementation for language toggle
  };

  const achievements = [
    {
      id: 'first_lesson',
      title: currentUser.language === 'en' ? 'First Steps' : 'Tillaabada Hore',
      description: currentUser.language === 'en' ? 'Complete your first lesson' : 'Dhammayso casharkaaga kowaad',
      achieved: completedLessons > 0,
      icon: Trophy
    },
    {
      id: 'level_1_complete',
      title: currentUser.language === 'en' ? 'Beginner Graduate' : 'Qalin-jabinta Bilaabaha',
      description: currentUser.language === 'en' ? 'Complete Level 1' : 'Dhammayso Heerka 1',
      achieved: level1Progress === 100,
      icon: Award
    },
    {
      id: 'streak_5',
      title: currentUser.language === 'en' ? 'Consistent Learner' : 'Barasho Joogto ah',
      description: currentUser.language === 'en' ? '5 day learning streak' : '5 maalmood barashada joogto ah',
      achieved: currentUser.streak >= 5,
      icon: Calendar
    },
    {
      id: 'half_complete',
      title: currentUser.language === 'en' ? 'Halfway Hero' : 'Geesi Badhkii',
      description: currentUser.language === 'en' ? 'Complete 50% of all lessons' : 'Dhammayso 50% dhammaan casharrada',
      achieved: overallProgress >= 50,
      icon: Target
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        user={currentUser} 
        onLanguageToggle={toggleLanguage}
      />
      
      <main className="max-w-md mx-auto px-4 py-6 space-y-6 pb-24">
        {/* Header */}
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation('/')}
            className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200"
          >
            <ArrowLeft className="h-4 w-4 text-gray-600" />
          </Button>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-gray-900">
              {currentUser.language === 'en' ? 'Your Progress' : 'Horumaarkaaga'}
            </h2>
            <p className="text-sm text-gray-500">
              {currentUser.language === 'en' ? 'Track your learning journey' : 'La soco socdaalka waxbarashada'}
            </p>
          </div>
        </div>

        {/* Study Streak */}
        <StudyStreak 
          streak={currentUser.streak}
          weeklyGoal={5}
          completedThisWeek={3}
          language={currentUser.language}
        />

        {/* Overall Progress */}
        <Card className="p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            {currentUser.language === 'en' ? 'Overall Progress' : 'Horumarinta Guud'}
          </h3>
          <LessonProgressBar 
            totalLessons={totalLessons}
            completedLessons={completedLessons}
            language={currentUser.language}
          />
        </Card>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="p-4 text-center bg-blue-50 border-blue-200">
            <BookOpen className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <p className="text-xl font-bold text-blue-900">{completedLessons}</p>
            <p className="text-xs text-blue-700">
              {currentUser.language === 'en' ? 'Lessons Done' : 'Casharrada la dhammaystiray'}
            </p>
          </Card>
          
          <Card className="p-4 text-center bg-green-50 border-green-200">
            <Trophy className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <p className="text-xl font-bold text-green-900">{averageQuizScore}%</p>
            <p className="text-xs text-green-700">
              {currentUser.language === 'en' ? 'Average Score' : 'Dhibcaha Celceliska'}
            </p>
          </Card>
        </div>

        {/* Level Progress */}
        <Card className="p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            {currentUser.language === 'en' ? 'Level Progress' : 'Horumarinta Heerka'}
          </h3>
          <div className="space-y-4">
            {[
              { level: 1, name: currentUser.language === 'en' ? 'Beginner' : 'Bilaabaha', progress: level1Progress, color: 'bg-green-500' },
              { level: 2, name: currentUser.language === 'en' ? 'Intermediate' : 'Dhexdhexaad', progress: level2Progress, color: 'bg-blue-500' },
              { level: 3, name: currentUser.language === 'en' ? 'Advanced' : 'Sare', progress: level3Progress, color: 'bg-purple-500' }
            ].map((levelData) => (
              <div key={levelData.level} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="font-medium text-gray-700">
                    {currentUser.language === 'en' ? `Level ${levelData.level}` : `Heer ${levelData.level}`} - {levelData.name}
                  </span>
                  <span className="text-gray-600">{levelData.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`${levelData.color} h-2 rounded-full transition-all duration-300`}
                    style={{ width: `${levelData.progress}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Achievements */}
        <Card className="p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            {currentUser.language === 'en' ? 'Achievements' : 'Guulaha'}
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {achievements.map((achievement) => {
              const Icon = achievement.icon;
              return (
                <div 
                  key={achievement.id} 
                  className={`p-3 rounded-lg border text-center ${
                    achievement.achieved 
                      ? 'bg-yellow-50 border-yellow-200' 
                      : 'bg-gray-50 border-gray-200 opacity-50'
                  }`}
                >
                  <div className={`w-10 h-10 mx-auto rounded-full flex items-center justify-center mb-2 ${
                    achievement.achieved 
                      ? 'bg-yellow-100' 
                      : 'bg-gray-100'
                  }`}>
                    <Icon className={`h-5 w-5 ${
                      achievement.achieved 
                        ? 'text-yellow-600' 
                        : 'text-gray-400'
                    }`} />
                  </div>
                  <h4 className="text-xs font-medium text-gray-900 mb-1">{achievement.title}</h4>
                  <p className="text-xs text-gray-600">{achievement.description}</p>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Recent Activity */}
        {recentCompletions.length > 0 && (
          <Card className="p-6 shadow-sm border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              {currentUser.language === 'en' ? 'Recent Activity' : 'Hawlaha Dhowaanta'}
            </h3>
            <div className="space-y-3">
              {recentCompletions.map((completion) => {
                const lesson = [...level1Lessons, ...level2Lessons, ...level3Lessons]
                  .find(l => l.id === completion.lessonId);
                if (!lesson) return null;
                
                return (
                  <div key={completion.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <Trophy className="h-4 w-4 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">{lesson.title}</p>
                      <p className="text-xs text-gray-500">
                        {currentUser.language === 'en' ? 'Score:' : 'Dhibcaha:'} {completion.quizScore || 0}%
                      </p>
                    </div>
                    <span className="text-xs text-gray-500">
                      {completion.completedAt ? new Date(completion.completedAt).toLocaleDateString() : ''}
                    </span>
                  </div>
                );
              })}
            </div>
          </Card>
        )}
      </main>

      <BottomNav currentPage="progress" language={currentUser.language} />
    </div>
  );
}