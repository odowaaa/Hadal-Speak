import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { ArrowLeft, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Header from "../components/header";
import BottomNav from "../components/bottom-nav";
import { Lesson, UserProgress } from "@shared/schema";

export default function Lessons() {
  const [, setLocation] = useLocation();
  const [currentUser] = useState({ 
    id: 'demo-user', 
    username: 'demo', 
    language: 'en' as 'en' | 'so'
  });

  // Get lessons for each level
  const { data: level1Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/level/1"]
  });

  const { data: level2Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/level/2"]
  });

  const { data: level3Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/level/3"]
  });

  const { data: userProgress = [] } = useQuery<UserProgress[]>({
    queryKey: ["/api/progress", currentUser.id]
  });

  const allLessons = [...level1Lessons, ...level2Lessons, ...level3Lessons];

  const isLessonCompleted = (lessonId: string) => {
    return userProgress.some(p => p.lessonId === lessonId && p.completed);
  };

  const getLevelColor = (level: number) => {
    switch (level) {
      case 1: return "bg-green-100 text-green-700";
      case 2: return "bg-blue-100 text-blue-700";
      case 3: return "bg-purple-100 text-purple-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const getLevelName = (level: number) => {
    if (currentUser.language === 'en') {
      switch (level) {
        case 1: return "Beginner";
        case 2: return "Intermediate";
        case 3: return "Advanced";
        default: return "Unknown";
      }
    } else {
      switch (level) {
        case 1: return "Bilaabaha";
        case 2: return "Dhexdhexaad";
        case 3: return "Sare";
        default: return "La garanayo";
      }
    }
  };

  const toggleLanguage = () => {
    // Implementation for language toggle
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        user={currentUser} 
        onLanguageToggle={toggleLanguage}
      />
      
      <main className="max-w-md mx-auto px-4 py-6 space-y-6 pb-24">
        {/* Header */}
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation('/')}
            className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200"
          >
            <ArrowLeft className="h-4 w-4 text-gray-600" />
          </Button>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-gray-900">
              {currentUser.language === 'en' ? 'All Lessons' : 'Dhammaan Casharrada'}
            </h2>
            <p className="text-sm text-gray-500">
              {currentUser.language === 'en' ? `${allLessons.length} lessons available` : `${allLessons.length} cashar la heli karo`}
            </p>
          </div>
        </div>

        {/* Lessons List */}
        <div className="space-y-4">
          {allLessons.map((lesson) => (
            <Card key={lesson.id} className="p-4 shadow-sm border border-gray-100">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    {isLessonCompleted(lesson.id) ? (
                      <i className="fas fa-check text-green-600 text-lg"></i>
                    ) : (
                      <BookOpen className="h-5 w-5 text-blue-600" />
                    )}
                  </div>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{lesson.title}</h3>
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${getLevelColor(lesson.level)}`}>
                      {currentUser.language === 'en' ? `Level ${lesson.level}` : `Heer ${lesson.level}`} - {getLevelName(lesson.level)}
                    </span>
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-2">{lesson.english}</p>
                  <p className="text-sm text-cultural mb-3">{lesson.somali}</p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">
                      {currentUser.language === 'en' ? `Lesson ${lesson.lessonNumber}` : `Cashar ${lesson.lessonNumber}`}
                    </span>
                    
                    <Button
                      onClick={() => setLocation(`/lesson/${lesson.level}/${lesson.id}`)}
                      size="sm"
                      className="text-xs"
                    >
                      {isLessonCompleted(lesson.id)
                        ? (currentUser.language === 'en' ? 'Review' : 'Dib u eeg')
                        : (currentUser.language === 'en' ? 'Start' : 'Bilow')
                      }
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </main>

      <BottomNav currentPage="lessons" language={currentUser.language} />
    </div>
  );
}