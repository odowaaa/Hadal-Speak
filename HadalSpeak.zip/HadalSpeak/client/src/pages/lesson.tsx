import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation, useParams } from "wouter";
import { ArrowLeft, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Header from "../components/header";
import LessonCard from "../components/lesson-card";
import Quiz from "../components/quiz";
import BottomNav from "../components/bottom-nav";
import { Lesson, UserProgress, QuizQuestion } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function LessonPage() {
  const params = useParams<{ level: string; lessonId: string }>();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  
  const [currentUser] = useState({ 
    id: 'demo-user', 
    username: 'demo', 
    language: 'en' as 'en' | 'so'
  });

  const level = parseInt(params.level || "1");
  const lessonId = params.lessonId || "";

  // Get all lessons for this level
  const { data: levelLessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/level", level]
  });

  // Get current lesson
  const { data: currentLesson } = useQuery<Lesson>({
    queryKey: ["/api/lessons", lessonId]
  });

  // Get quiz questions
  const { data: quizQuestions = [] } = useQuery<QuizQuestion[]>({
    queryKey: ["/api/lessons", lessonId, "quiz"]
  });

  // Get user progress
  const { data: userProgress = [] } = useQuery<UserProgress[]>({
    queryKey: ["/api/progress", currentUser.id]
  });

  // Mark lesson as completed
  const completeLessonMutation = useMutation({
    mutationFn: async (data: { lessonId: string; completed: boolean; quizScore?: number }) => {
      return await apiRequest("POST", "/api/progress", {
        userId: currentUser.id,
        lessonId: data.lessonId,
        completed: data.completed,
        quizScore: data.quizScore,
        completedAt: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/progress", currentUser.id] });
    }
  });

  const currentLessonIndex = levelLessons.findIndex(l => l.id === lessonId);
  const isCompleted = userProgress.some(p => p.lessonId === lessonId && p.completed);

  const handleNext = () => {
    const nextIndex = currentLessonIndex + 1;
    if (nextIndex < levelLessons.length) {
      setLocation(`/lesson/${level}/${levelLessons[nextIndex].id}`);
    } else {
      // Go to next level or back to home
      setLocation('/');
    }
  };

  const handlePrevious = () => {
    const prevIndex = currentLessonIndex - 1;
    if (prevIndex >= 0) {
      setLocation(`/lesson/${level}/${levelLessons[prevIndex].id}`);
    }
  };

  const handleQuizComplete = (score: number) => {
    const percentage = Math.round((score / quizQuestions.length) * 100);
    completeLessonMutation.mutate({
      lessonId,
      completed: true,
      quizScore: percentage
    });
  };

  const toggleLanguage = () => {
    // Implementation for language toggle
  };

  if (!currentLesson) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        user={currentUser} 
        onLanguageToggle={toggleLanguage}
      />
      
      <main className="max-w-md mx-auto px-4 py-6 space-y-6 pb-24">
        {/* Lesson Header */}
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation('/')}
            className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200"
          >
            <ArrowLeft className="h-4 w-4 text-gray-600" />
          </Button>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-gray-900">
              {currentUser.language === 'en' ? `Level ${level}: ${level === 1 ? 'Beginner' : level === 2 ? 'Intermediate' : 'Advanced'}` : `Heer ${level}`}
            </h2>
            <p className="text-sm text-gray-500">
              {currentUser.language === 'en' ? `Lesson ${currentLessonIndex + 1} of ${levelLessons.length}` : `Cashar ${currentLessonIndex + 1} oo ka mid ah ${levelLessons.length}`}
            </p>
          </div>
        </div>

        {/* Lesson Content */}
        <LessonCard
          lesson={currentLesson}
          isCompleted={isCompleted}
          language={currentUser.language}
        />

        {/* Navigation */}
        <div className="flex space-x-3 pt-4">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentLessonIndex === 0}
            className="flex-1"
          >
            <ChevronLeft className="h-4 w-4 mr-2" />
            {currentUser.language === 'en' ? 'Previous' : 'Hore'}
          </Button>
          <Button
            onClick={handleNext}
            disabled={currentLessonIndex === levelLessons.length - 1}
            className="flex-1"
          >
            {currentUser.language === 'en' ? 'Next' : 'Xiga'}
            <ChevronRight className="h-4 w-4 ml-2" />
          </Button>
        </div>

        {/* Quiz Section */}
        {quizQuestions.length > 0 && (
          <Quiz
            questions={quizQuestions}
            onComplete={handleQuizComplete}
            language={currentUser.language}
          />
        )}
      </main>

      <BottomNav currentPage="lessons" language={currentUser.language} />
    </div>
  );
}
