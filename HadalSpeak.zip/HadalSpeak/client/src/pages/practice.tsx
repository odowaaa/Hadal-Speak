import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Mic, Volume2, Play, RotateCcw, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Header from "../components/header";
import BottomNav from "../components/bottom-nav";
import VoiceRecorder from "../components/voice-recorder";
import AudioPlayer from "../components/audio-player";
import VocabularyFlashcard from "../components/vocabulary-flashcard";
import PronunciationGuide from "../components/pronunciation-guide";
import { Lesson } from "@shared/schema";
import { useLocation } from "wouter";

export default function Practice() {
  const [, setLocation] = useLocation();
  const [currentUser] = useState({ 
    id: 'demo-user', 
    username: 'demo', 
    language: 'en' as 'en' | 'so'
  });
  const [currentPracticeIndex, setCurrentPracticeIndex] = useState(0);
  const [practiceMode, setPracticeMode] = useState<'speaking' | 'vocabulary' | 'pronunciation'>('speaking');

  // Get all lessons for practice
  const { data: level1Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/level/1"]
  });

  const { data: level2Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/level/2"]
  });

  const { data: level3Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/level/3"]
  });

  const allLessons = [...level1Lessons, ...level2Lessons, ...level3Lessons];
  const currentLesson = allLessons[currentPracticeIndex];

  const handleNext = () => {
    if (currentPracticeIndex < allLessons.length - 1) {
      setCurrentPracticeIndex(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentPracticeIndex > 0) {
      setCurrentPracticeIndex(prev => prev - 1);
    }
  };

  const handleRandom = () => {
    const randomIndex = Math.floor(Math.random() * allLessons.length);
    setCurrentPracticeIndex(randomIndex);
  };

  const toggleLanguage = () => {
    // Implementation for language toggle
  };

  if (!currentLesson) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header user={currentUser} onLanguageToggle={toggleLanguage} />
        <div className="max-w-md mx-auto px-4 py-6 pb-24">
          <div className="text-center">
            <p className="text-gray-500">
              {currentUser.language === 'en' ? 'Loading practice session...' : 'La rarayaa dhigaalka...'}
            </p>
          </div>
        </div>
        <BottomNav currentPage="practice" language={currentUser.language} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        user={currentUser} 
        onLanguageToggle={toggleLanguage}
      />
      
      <main className="max-w-md mx-auto px-4 py-6 space-y-6 pb-24">
        {/* Header */}
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation('/')}
            className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200"
          >
            <ArrowLeft className="h-4 w-4 text-gray-600" />
          </Button>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-gray-900">
              {currentUser.language === 'en' ? 'Speaking Practice' : 'Ku Celceli Hadalka'}
            </h2>
            <p className="text-sm text-gray-500">
              {currentUser.language === 'en' ? 
                `Practice ${currentPracticeIndex + 1} of ${allLessons.length}` : 
                `Ku celi ${currentPracticeIndex + 1} oo ka mid ah ${allLessons.length}`
              }
            </p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRandom}
            className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200"
            title={currentUser.language === 'en' ? 'Random lesson' : 'Cashar aan la filanayn'}
          >
            <RotateCcw className="h-4 w-4 text-gray-600" />
          </Button>
        </div>

        {/* Practice Mode Selector */}
        <div className="grid grid-cols-3 gap-2 p-1 bg-gray-100 rounded-lg">
          <Button
            variant={practiceMode === 'speaking' ? 'default' : 'ghost'}
            onClick={() => setPracticeMode('speaking')}
            className="text-xs"
          >
            <Mic className="h-3 w-3 mr-1" />
            {currentUser.language === 'en' ? 'Speaking' : 'Hadal'}
          </Button>
          <Button
            variant={practiceMode === 'vocabulary' ? 'default' : 'ghost'}
            onClick={() => setPracticeMode('vocabulary')}
            className="text-xs"
          >
            <BookOpen className="h-3 w-3 mr-1" />
            {currentUser.language === 'en' ? 'Vocab' : 'Erayada'}
          </Button>
          <Button
            variant={practiceMode === 'pronunciation' ? 'default' : 'ghost'}
            onClick={() => setPracticeMode('pronunciation')}
            className="text-xs"
          >
            <Volume2 className="h-3 w-3 mr-1" />
            {currentUser.language === 'en' ? 'Sounds' : 'Dhawaqa'}
          </Button>
        </div>

        {/* Practice Content */}
        {practiceMode === 'speaking' && (
          <Card className="p-6 shadow-sm border border-gray-100 space-y-6">
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <Mic className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">{currentLesson.title}</h3>
            <span className="text-xs px-3 py-1 bg-blue-100 text-blue-700 rounded-full font-medium">
              {currentUser.language === 'en' ? `Level ${currentLesson.level}` : `Heer ${currentLesson.level}`}
            </span>
          </div>

          {/* English Text */}
          <div className="bg-blue-50 rounded-xl p-4">
            <div className="flex items-start justify-between mb-2">
              <h4 className="text-sm font-medium text-blue-900">
                {currentUser.language === 'en' ? 'Practice saying:' : 'Ku celi dhididda:'}
              </h4>
              <AudioPlayer text={currentLesson.english} language="en" />
            </div>
            <p className="text-lg font-medium text-blue-900">{currentLesson.english}</p>
          </div>

          {/* Somali Translation */}
          <div className="bg-cultural/10 rounded-xl p-4">
            <div className="flex items-start justify-between mb-2">
              <h4 className="text-sm font-medium text-cultural">
                {currentUser.language === 'en' ? 'Translation:' : 'Turjumaada:'}
              </h4>
              <AudioPlayer text={currentLesson.somali} language="so" />
            </div>
            <p className="text-lg font-medium text-cultural">{currentLesson.somali}</p>
          </div>

          {/* Voice Practice */}
          <VoiceRecorder 
            targetText={currentLesson.english}
            language={currentUser.language}
          />

          {/* Key Words */}
          <div className="bg-gray-50 rounded-xl p-4">
            <h4 className="text-sm font-medium text-gray-700 mb-3">
              {currentUser.language === 'en' ? 'Key Words' : 'Erayada Muhiimka ah'}
            </h4>
            <div className="grid grid-cols-1 gap-2">
              {Object.entries(currentLesson.keyWords).map(([english, somali]) => (
                <div key={english} className="flex justify-between items-center text-sm">
                  <span className="text-gray-900 font-medium">{english}</span>
                  <span className="text-gray-600">=</span>
                  <span className="text-cultural font-medium">{somali}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>
        )}

        {/* Vocabulary Practice */}
        {practiceMode === 'vocabulary' && (
          <div className="space-y-6">
            {/* Header */}
            <div className="text-center space-y-2">
              <h3 className="text-xl font-bold text-gray-900">
                {currentUser.language === 'en' ? 'Vocabulary Practice' : 'Ku Celceli Erayada'}
              </h3>
              <p className="text-sm text-gray-600">
                {currentUser.language === 'en' 
                  ? `Learn ${Object.keys(currentLesson.keyWords).length} key words from "${currentLesson.title}"`
                  : `Baro ${Object.keys(currentLesson.keyWords).length} eray oo muhiim ah oo ka mid ah "${currentLesson.title}"`
                }
              </p>
            </div>

            {/* Lesson Context */}
            <Card className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
              <div className="text-center space-y-2">
                <h4 className="text-sm font-medium text-blue-800">
                  {currentUser.language === 'en' ? 'From this lesson:' : 'Casharkan ka soo baxay:'}
                </h4>
                <p className="text-blue-900 font-medium">{currentLesson.english}</p>
                <p className="text-purple-700">{currentLesson.somali}</p>
              </div>
            </Card>

            {/* Vocabulary Cards */}
            <div className="space-y-4">
              {Object.entries(currentLesson.keyWords).map(([english, somali], index) => (
                <div key={index}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-gray-500">
                      {currentUser.language === 'en' ? `Word ${index + 1} of ${Object.keys(currentLesson.keyWords).length}` : `Erayga ${index + 1} ee ${Object.keys(currentLesson.keyWords).length}`}
                    </span>
                  </div>
                  <VocabularyFlashcard
                    englishWord={english}
                    somaliWord={somali}
                    example={`"${currentLesson.english}"`}
                    somaliExample={`"${currentLesson.somali}"`}
                    language={currentUser.language}
                  />
                </div>
              ))}
            </div>

            {/* Study Tips */}
            <Card className="p-4 bg-yellow-50 border-yellow-200">
              <h4 className="text-sm font-semibold text-yellow-800 mb-2">
                {currentUser.language === 'en' ? 'Study Tips:' : 'Tilmaamaha Waxbarasho:'}
              </h4>
              <ul className="space-y-1 text-sm text-yellow-700">
                <li>• {currentUser.language === 'en' ? 'Practice saying each word out loud' : 'Ku celi eray kasta oo cod dheer'}</li>
                <li>• {currentUser.language === 'en' ? 'Use the flip feature to test yourself' : 'Isticmaal "Rogaal" si aad is tijaabiso'}</li>
                <li>• {currentUser.language === 'en' ? 'Listen to pronunciation multiple times' : 'Dhegeyso dhawaqa mar badan'}</li>
              </ul>
            </Card>
          </div>
        )}

        {/* Pronunciation Practice */}
        {practiceMode === 'pronunciation' && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 text-center">
              {currentUser.language === 'en' ? 'Pronunciation Practice' : 'Ku Celceli Dhawaqa'}
            </h3>
            {Object.entries(currentLesson.keyWords).slice(0, 2).map(([english, somali], index) => (
              <PronunciationGuide
                key={index}
                word={english}
                phonetic={english.toLowerCase().replace(/[aeiou]/g, (vowel) => {
                  const phonetics: Record<string, string> = { 'a': 'eɪ', 'e': 'iː', 'i': 'aɪ', 'o': 'oʊ', 'u': 'uː' };
                  return phonetics[vowel] || vowel;
                })}
                tips={[
                  currentUser.language === 'en' 
                    ? `In Somali, this is pronounced as "${somali}"`
                    : `Af-Soomaaliga, waxaa loo dhahaa "${somali}"`,
                  currentUser.language === 'en'
                    ? 'Break it down into syllables'
                    : 'U kala qaybi erayada',
                  currentUser.language === 'en'
                    ? 'Practice slowly at first'
                    : 'Marka hore si tartiib ah u ku celi'
                ]}
                language={currentUser.language}
              />
            ))}
          </div>
        )}

        {/* Navigation */}
        <div className="flex space-x-3">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentPracticeIndex === 0}
            className="flex-1"
          >
            {currentUser.language === 'en' ? 'Previous' : 'Hore'}
          </Button>
          <Button
            onClick={handleNext}
            disabled={currentPracticeIndex === allLessons.length - 1}
            className="flex-1"
          >
            {currentUser.language === 'en' ? 'Next' : 'Xiga'}
          </Button>
        </div>
      </main>

      <BottomNav currentPage="practice" language={currentUser.language} />
    </div>
  );
}