import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Header from "../components/header";
import LevelCard from "../components/level-card";
import BottomNav from "../components/bottom-nav";
import StudyStreak from "../components/study-streak";
import LessonProgressBar from "../components/lesson-progress-bar";
import { Lesson, UserProgress } from "@shared/schema";

export default function Home() {
  const [, setLocation] = useLocation();
  const [currentUser, setCurrentUser] = useState({ 
    id: 'demo-user', 
    username: 'demo', 
    language: 'en',
    streak: 5,
    overallProgress: 0
  });

  // Get lessons for each level to calculate progress
  const { data: level1Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/level/1"]
  });

  const { data: level2Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/level/2"]
  });

  const { data: level3Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/level/3"]
  });

  const { data: userProgress = [] } = useQuery<UserProgress[]>({
    queryKey: ["/api/progress", currentUser.id]
  });

  // Calculate progress for each level
  const getProgressForLevel = (lessons: Lesson[]) => {
    if (lessons.length === 0) return 0;
    const completedCount = lessons.filter(lesson => 
      userProgress.some(p => p.lessonId === lesson.id && p.completed)
    ).length;
    return Math.round((completedCount / lessons.length) * 100);
  };

  const level1Progress = getProgressForLevel(level1Lessons);
  const level2Progress = getProgressForLevel(level2Lessons);
  const level3Progress = getProgressForLevel(level3Lessons);

  // Calculate overall progress
  const totalLessons = level1Lessons.length + level2Lessons.length + level3Lessons.length;
  const totalCompleted = userProgress.filter(p => p.completed).length;
  const overallProgress = totalLessons > 0 ? Math.round((totalCompleted / totalLessons) * 100) : 0;

  const handleLevelSelect = (level: number) => {
    const lessons = level === 1 ? level1Lessons : level === 2 ? level2Lessons : level3Lessons;
    if (lessons.length > 0) {
      setLocation(`/lesson/${level}/${lessons[0].id}`);
    }
  };

  const toggleLanguage = () => {
    setCurrentUser(prev => ({
      ...prev,
      language: prev.language === 'en' ? 'so' : 'en'
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        user={currentUser} 
        onLanguageToggle={toggleLanguage}
      />
      
      <main className="max-w-md mx-auto px-4 py-6 space-y-6 pb-24">
        {/* Study Streak */}
        <StudyStreak 
          streak={currentUser.streak}
          weeklyGoal={5}
          completedThisWeek={3}
          language={currentUser.language as 'en' | 'so'}
        />

        {/* Progress Overview */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            {currentUser.language === 'en' ? 'Learning Progress' : 'Horumarinta Waxbarasho'}
          </h2>
          <LessonProgressBar 
            totalLessons={totalLessons}
            completedLessons={totalCompleted}
            language={currentUser.language as 'en' | 'so'}
          />
        </div>

        {/* Level Selection */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-gray-900">
            {currentUser.language === 'en' ? 'Choose Your Level' : 'Dooro Heerkaaga'}
          </h2>
          
          <LevelCard
            level={1}
            title={currentUser.language === 'en' ? 'Level 1: Beginner' : 'Heer 1: Bilaabaha'}
            description={currentUser.language === 'en' ? 'Basic greetings, introductions, daily phrases' : 'Salaan asaasi ah, is-aqoontin, weedho maalinta'}
            icon="fas fa-seedling"
            progress={level1Progress}
            completedLessons={level1Lessons.filter(l => userProgress.some(p => p.lessonId === l.id && p.completed)).length}
            totalLessons={level1Lessons.length}
            bgColor="bg-green-100"
            iconColor="text-green-600"
            progressColor="bg-green-500"
            badgeColor="bg-green-100 text-green-700"
            isLocked={false}
            onSelect={() => handleLevelSelect(1)}
            language={currentUser.language}
          />

          <LevelCard
            level={2}
            title={currentUser.language === 'en' ? 'Level 2: Intermediate' : 'Heer 2: Dhexdhexaad'}
            description={currentUser.language === 'en' ? 'Conversations, work, shopping, health topics' : 'Wada hadal, shaqo, wax iibsiga, arrimaha caafimaadka'}
            icon="fas fa-mountain"
            progress={level2Progress}
            completedLessons={level2Lessons.filter(l => userProgress.some(p => p.lessonId === l.id && p.completed)).length}
            totalLessons={level2Lessons.length}
            bgColor="bg-blue-100"
            iconColor="text-blue-600"
            progressColor="bg-blue-500"
            badgeColor="bg-blue-100 text-blue-700"
            isLocked={level1Progress < 50}
            onSelect={() => handleLevelSelect(2)}
            language={currentUser.language}
          />

          <LevelCard
            level={3}
            title={currentUser.language === 'en' ? 'Level 3: Advanced' : 'Heer 3: Sare'}
            description={currentUser.language === 'en' ? 'Storytelling, opinions, formal communication' : 'Sheeko sheegid, fikrado, xiriir rasmi ah'}
            icon="fas fa-crown"
            progress={level3Progress}
            completedLessons={level3Lessons.filter(l => userProgress.some(p => p.lessonId === l.id && p.completed)).length}
            totalLessons={level3Lessons.length}
            bgColor="bg-purple-100"
            iconColor="text-purple-600"
            progressColor="bg-purple-500"
            badgeColor="bg-purple-100 text-purple-700"
            isLocked={level2Progress < 50}
            onSelect={() => handleLevelSelect(3)}
            language={currentUser.language}
          />
        </div>

        {/* Daily Goals */}
        <div className="bg-gradient-to-r from-cultural to-blue-500 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold">
              {currentUser.language === 'en' ? "Today's Goal" : 'Hadafka Maanta'}
            </h2>
            <i className="fas fa-target text-2xl opacity-80"></i>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-blue-100">
                {currentUser.language === 'en' ? 'Complete 1 lesson' : '1 cashar dhammayso'}
              </span>
              <div className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center">
                  <i className="fas fa-check text-white text-xs"></i>
                </div>
                <span className="text-sm font-medium">
                  {currentUser.language === 'en' ? 'Done!' : 'La dhammaystiray!'}
                </span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-blue-100">
                {currentUser.language === 'en' ? 'Practice speaking' : 'Ku celceli hadalka'}
              </span>
              <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center">
                <div className="w-2 h-2 bg-white rounded-full"></div>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-blue-100">
                {currentUser.language === 'en' ? 'Score 80% on quiz' : 'Imtixaanka 80% ka hel'}
              </span>
              <div className="w-6 h-6 bg-white/20 rounded-full"></div>
            </div>
          </div>
        </div>
      </main>

      <BottomNav currentPage="home" language={currentUser.language} />
    </div>
  );
}
