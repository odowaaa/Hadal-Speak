import { useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft, Shield, Eye, Lock, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Header from "../components/header";
import BottomNav from "../components/bottom-nav";

export default function PrivacyPolicy() {
  const [, setLocation] = useLocation();
  const [currentUser] = useState({ 
    id: 'demo-user', 
    username: 'demo', 
    language: 'en' as 'en' | 'so',
    streak: 5,
    overallProgress: 0
  });

  const toggleLanguage = () => {
    // Language toggle functionality
  };

  const privacyContent = {
    en: {
      title: "Privacy Policy",
      subtitle: "How we protect your data",
      lastUpdated: "Last Updated: January 30, 2025",
      sections: [
        {
          icon: Eye,
          title: "Information We Collect",
          content: [
            "• Learning progress and quiz scores",
            "• Voice recordings (stored locally on your device)",
            "• App usage patterns to improve your experience",
            "• Language preferences and settings"
          ]
        },
        {
          icon: Lock,
          title: "How We Use Your Data",
          content: [
            "• Provide personalized learning experiences",
            "• Track your progress across lessons",
            "• Improve our educational content",
            "• Send lesson reminders (with your permission)"
          ]
        },
        {
          icon: Shield,
          title: "Data Protection",
          content: [
            "• Your data is encrypted and secure",
            "• Voice recordings stay on your device",
            "• No personal data is sold to third parties",
            "• You can delete your data anytime"
          ]
        },
        {
          icon: FileText,
          title: "Your Rights",
          content: [
            "• Access your personal data",
            "• Correct inaccurate information",
            "• Delete your account and data",
            "• Opt-out of data collection"
          ]
        }
      ],
      contact: {
        title: "Questions?",
        text: "Contact our developer for privacy concerns:",
        email: "odowaa1996@gmail.com",
        whatsapp: "+252616538992"
      }
    },
    so: {
      title: "Siyaasadda Sirta",
      subtitle: "Sida aan u ilaalino xogahaaga",
      lastUpdated: "La cusboonaysiiyay: Janayir 30, 2025",
      sections: [
        {
          icon: Eye,
          title: "Xogta aan Ururino",
          content: [
            "• Horumarkaaga waxbarashada iyo natiijooyinka imtixaanka",
            "• Duubista codka (lagu kaydinayo aaladdaada)",
            "• Isticmaalka app-ka si aan u hagaajino khibradaada",
            "• Doorashada luqadda iyo dejinta"
          ]
        },
        {
          icon: Lock,
          title: "Sida aan u Isticmaalno Xogahaaga",
          content: [
            "• Bixin waayo-aragnimo shakhsi ah oo waxbarasho",
            "• La socodka horumarkaaga casharrada oo dhan",
            "• Hagaajinta nuxurka waxbarashadayada",
            "• Diritaanka xusuusinta casharrada (idinku ogolaanshaha)"
          ]
        },
        {
          icon: Shield,
          title: "Ilaalinta Xogta",
          content: [
            "• Xogahaagu waa la qariyey oo ammaan ah",
            "• Duubista codku waxay ku hadhaa aaladdaada",
            "• Xog shakhsi ah looma iibiyo qof kale",
            "• Waqti kasta xogahaaga tirtiri kartaa"
          ]
        },
        {
          icon: FileText,
          title: "Xuquuqdaada",
          content: [
            "• Helitaanka xogahaaga shakhsiga ah",
            "• Saxida macluumaad khaldan",
            "• Tirtiritaanka koontadaada iyo xogta",
            "• Ka bixista ururinta xogta"
          ]
        }
      ],
      contact: {
        title: "Su'aalo?",
        text: "Kala xiriir horumariyaha arrimo sir ah:",
        email: "odowaa1996@gmail.com",
        whatsapp: "+252616538992"
      }
    }
  };

  const content = privacyContent[currentUser.language];

  return (
    <div className="min-h-screen bg-background dark:bg-background transition-colors duration-200">
      <Header 
        user={currentUser} 
        onLanguageToggle={toggleLanguage}
      />
      
      <main className="max-w-md mx-auto px-4 py-6 space-y-6 pb-24">
        {/* Header */}
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation('/profile')}
            className="p-2 rounded-lg bg-muted hover:bg-muted/80 transition-colors duration-200"
          >
            <ArrowLeft className="h-4 w-4 text-muted-foreground" />
          </Button>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-foreground">
              {content.title}
            </h2>
            <p className="text-sm text-muted-foreground">
              {content.subtitle}
            </p>
          </div>
        </div>

        {/* Last Updated */}
        <Card className="p-4 bg-muted/50 border-border transition-colors duration-200">
          <p className="text-xs text-muted-foreground text-center">
            {content.lastUpdated}
          </p>
        </Card>

        {/* Privacy Sections */}
        <div className="space-y-4">
          {content.sections.map((section, index) => (
            <Card key={index} className="p-6 border-border bg-card transition-colors duration-200">
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                  <section.icon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-foreground mb-3">
                    {section.title}
                  </h3>
                  <div className="space-y-2">
                    {section.content.map((item, itemIndex) => (
                      <p key={itemIndex} className="text-sm text-muted-foreground">
                        {item}
                      </p>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Contact Information */}
        <Card className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 border-border transition-colors duration-200">
          <h3 className="text-lg font-semibold text-foreground mb-3 flex items-center">
            <Shield className="h-5 w-5 mr-2 text-blue-600" />
            {content.contact.title}
          </h3>
          <p className="text-sm text-muted-foreground mb-3">
            {content.contact.text}
          </p>
          <div className="space-y-2">
            <button
              onClick={() => window.open(`mailto:${content.contact.email}`, '_blank')}
              className="flex items-center text-sm text-blue-600 hover:text-blue-700 transition-colors"
            >
              <span className="mr-2">✉️</span>
              <span>{content.contact.email}</span>
            </button>
            <button
              onClick={() => window.open(`https://wa.me/252616538992`, '_blank')}
              className="flex items-center text-sm text-green-600 hover:text-green-700 transition-colors"
            >
              <span className="mr-2">📱</span>
              <span>{content.contact.whatsapp}</span>
            </button>
          </div>
        </Card>

        {/* Full Policy Link */}
        <Card className="p-4 border-border bg-card transition-colors duration-200">
          <div className="text-center">
            <p className="text-xs text-muted-foreground mb-2">
              {currentUser.language === 'en' 
                ? 'For the complete privacy policy, visit:'
                : 'Siyaasadda sirta oo dhamaystiran, booqo:'
              }
            </p>
            <a
              href="/privacy-policy-full"
              className="text-sm text-blue-600 hover:text-blue-700 underline"
              target="_blank"
              rel="noopener noreferrer"
            >
              {currentUser.language === 'en' 
                ? 'Full Privacy Policy'
                : 'Siyaasadda Sirta oo Dhamaystiran'
              }
            </a>
          </div>
        </Card>
      </main>

      <BottomNav />
    </div>
  );
}